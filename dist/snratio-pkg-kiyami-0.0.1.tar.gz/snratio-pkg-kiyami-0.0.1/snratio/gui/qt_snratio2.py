# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'snratio/gui/qt_snratio2.ui',
# licensing of 'snratio/gui/qt_snratio2.ui' applies.
#
# Created: Wed Apr  8 22:33:12 2020
#      by: pyside2-uic  running on PySide2 5.13.2
#
# WARNING! All changes made in this file will be lost!

