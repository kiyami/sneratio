# snratio
supernova ratio calculator
