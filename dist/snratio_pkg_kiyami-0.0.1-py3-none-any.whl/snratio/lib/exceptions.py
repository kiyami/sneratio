class ClobberError(ValueError):
    pass